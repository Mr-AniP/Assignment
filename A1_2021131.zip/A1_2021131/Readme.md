-----------------------------------------------------------------------------------------------------
Readme file Begins
-----------------------------------------------------------------------------------------------------
This file is the readme file for this assignment1 -> Course VLSI Design Flow 2024 under S.Saurabh sir IIITD submited by Animesh Pareek (2021131) Btech 3rd year student.

To run the scripts you need a linux shell / terminal (supporting bash scripts and tclsh ) and some verilog only testfiles (*.v) which need to be placed in an appropriate folder.

You may either keep your files in TestFiles folder  and the scripts or may alternatively pass your new test folder path to the scripts.

To do the latter please edit the line no. 5 of tcl script and line no. 3 of shell script (change the variable name to your testfolder path).

Next to run Q1.tcl script type `tclsh Q1.tcl` in your terminal.

Next to run Q2.sh script type `bash Q2.sh` in your terminal.

Word of Caution ->
Please Do note that you need to be in the current directory to run these files
-----------------------------------------------------------------------------------------------------
Readme file Ends
-----------------------------------------------------------------------------------------------------