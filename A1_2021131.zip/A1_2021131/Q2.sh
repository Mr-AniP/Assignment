#!/bin/bash
# begin the bash script
testdir="TestFiles" # directory containing test files
for file in $testdir/*.v;do # iterate through all .v files in the directory
# initialize counters
    always_count=0
    initial_count=0
    end_count=0
    begin_count=0
    case_count=0
    module_count=0
    while read line ; do # read each line of the file
        for word in $line;do # read each word of the line
            # check the words and increment the corresponding counter
            case $word in 
                '//'*) break ;; # if comment, ignore the rest of the line
                # increment the corresponding counter if the word is found and continue to the next word
                'initial') initial_count=$(($initial_count + 1));continue;; 
                'end') end_count=$(($end_count + 1));continue;;
                'begin') begin_count=$(($begin_count + 1));continue;;
                'module') module_count=$(($module_count + 1));continue;;
                'case'|'case('*) case_count=$(($case_count + 1));continue;;
                'always'|'always@'*) always_count=$(($always_count + 1));continue;;
                # if the word is not found and continue to the next word
                *) continue;; 
            esac
        done 
    done < "$file"
    # print the results for each file
    echo "File: $file"
    echo "Initial: $initial_count"
    echo "End: $end_count"
    echo "Begin: $begin_count"
    echo "Module: $module_count"
    echo "Case: $case_count"
    echo "Always: $always_count"
    echo "---------------------------------"
done
# ends the script